# Agentic AI Job Search

**End-to-end multi-resume job search** powered by **LangGraph** with **10 specialized agents**.

## What It Does (End-to-End)

For each resume, the system automatically:
1. Parses profile (skills, experience, target roles)
2. Discovers and ranks 12 job listings
3. Scores skill fit (0-100%)
4. Analyzes salary and researches companies (parallel)
5. Shortlists best matches and tracks applications
6. Writes tailored cover letters (top 3 jobs)
7. Generates optimized resume variants (top 3 jobs)
8. Prepares interview Q&A (top 2 jobs)
9. Produces a final actionable report

**Batch mode** runs all 6 resumes and generates a cross-candidate comparison report.

## Quick Start

```bash
pip install -r requirements.txt

# Run ALL 6 resumes end-to-end
python main.py demo-batch

# Launch interactive UI
streamlit run ui/app.py

# Single resume
python main.py demo
```

## Resume Library (6 Candidates)

| Candidate | Role Focus |
|-----------|------------|
| Alex Chen | ML Engineer / AI |
| Priya Sharma | Data Scientist |
| Marcus Johnson | DevOps / Platform |
| Elena Rodriguez | NLP Research |
| James Okafor | LLM / AI Engineer |
| Sarah Kim | Junior Software Engineer |

## CLI Commands

| Command | Description |
|---------|-------------|
| `python main.py demo-batch` | Run all 6 resumes end-to-end |
| `python main.py batch` | Batch run with options |
| `python main.py run` | Single resume pipeline |
| `python main.py resumes` | List resume library |
| `python main.py agents` | List LangGraph agents |
| `python main.py ui` | Launch Streamlit dashboard |

## Output

```
output/{run_id}/
├── comparison_report.txt
├── alex_chen_ml_engineer/
│   ├── cover_letter_*.txt
│   ├── optimized_resume_*.txt
│   └── final_report.txt
└── ... (per candidate)
```

## Documentation

Full notes: **[docs/NOTES.md](docs/NOTES.md)**

## Stack

LangGraph · OpenAI · Pydantic · Streamlit · Typer

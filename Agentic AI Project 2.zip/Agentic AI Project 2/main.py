"""CLI entry point for the Agentic AI Job Search system."""

from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import track
from rich.table import Table

import config
from graph.workflow import list_agents, run_pipeline
from models.schemas import UserProfile
from services.batch_runner import run_batch
from services.output_manager import save_candidate_results
from services.resume_loader import load_all_resumes, load_resume, load_resumes_by_ids

app = typer.Typer(
    name="jobsearch",
    help="Agentic AI Job Search — LangGraph multi-agent pipeline.",
)
console = Console()


def _load_profile(resume_path: Path | None) -> UserProfile:
    if resume_path and resume_path.exists():
        return load_resume(resume_path)
    resumes = load_all_resumes()
    if resumes:
        return resumes[0]
    return UserProfile()


def _save_results(state, output_dir: Path) -> None:
    save_candidate_results(state, run_id=output_dir.name if output_dir.name != "output" else "latest")


def _warn_demo_mode() -> None:
    if not config.OPENAI_API_KEY or config.OPENAI_API_KEY == "your_openai_api_key_here":
        console.print("[yellow]! Demo mode — set OPENAI_API_KEY in .env for live LLM.[/yellow]")


@app.command()
def run(
    query: str = typer.Option("", "--query", "-q", help="Job search query"),
    resume: Path = typer.Option(None, "--resume", "-r", help="Path to resume file"),
    output: Path = typer.Option(config.OUTPUT_DIR, "--output", "-o", help="Output directory"),
) -> None:
    """Run LangGraph pipeline for a single resume."""
    console.print(Panel.fit("[bold cyan]Agentic AI Job Search[/bold cyan]\n[dim]Single resume pipeline[/dim]"))
    _warn_demo_mode()

    profile = _load_profile(resume)
    console.print(f"[dim]Candidate: {profile.name} ({profile.candidate_id})[/dim]")
    console.print("[dim]Running LangGraph pipeline...[/dim]")

    state = run_pipeline(profile=profile, search_query=query)
    _save_results(state, output)
    _print_summary(state)
    console.print(f"\n[green]OK[/green] Saved to output/")


def _execute_batch(query: str = "", ids: str = "") -> None:
    if ids.strip():
        profiles = load_resumes_by_ids([x.strip() for x in ids.split(",")])
    else:
        profiles = load_all_resumes()

    if not profiles:
        console.print("[red]No resumes found in data/resumes/[/red]")
        raise typer.Exit(1)

    console.print(f"[dim]Processing {len(profiles)} resumes...[/dim]\n")

    def on_done(i, total, state):
        top = state.applications[0] if state.applications else None
        score = f"{top.match_score:.0f}%" if top else "N/A"
        console.print(f"  [{i}/{total}] {state.user_profile.name}: top match {score}")

    batch_result = run_batch(profiles, search_query=query, on_candidate_done=on_done)

    console.print(f"\n[green]Batch complete![/green] Run ID: {batch_result.run_id}")
    console.print(f"Output: output/{batch_result.run_id}/")
    console.print("\n[bold]Comparison (top 5):[/bold]")
    for m in batch_result.top_matches_overall[:5]:
        console.print(f"  [{m['match_score']:.0f}%] {m['candidate_name']} -> {m['job_title']} @ {m['company']}")


@app.command()
def batch(
    query: str = typer.Option("", "--query", "-q", help="Global search query"),
    ids: str = typer.Option("", "--ids", help="Comma-separated candidate IDs (default: all)"),
) -> None:
    """Run end-to-end pipeline for ALL resumes in data/resumes/."""
    console.print(Panel.fit("[bold cyan]Batch Job Search[/bold cyan]\n[dim]Multi-resume end-to-end[/dim]"))
    _warn_demo_mode()
    _execute_batch(query=query, ids=ids)


def _print_summary(state) -> None:
    table = Table(title="Top Job Matches", header_style="bold magenta")
    table.add_column("Score", width=8)
    table.add_column("Title")
    table.add_column("Company")
    table.add_column("Status")

    for app in state.applications[:8]:
        table.add_row(f"{app.match_score:.0f}%", app.job_title, app.company, app.status.value)
    console.print(table)


@app.command()
def agents() -> None:
    """List all LangGraph agents."""
    table = Table(title="LangGraph Agents", header_style="bold")
    table.add_column("#", width=4)
    table.add_column("Agent", style="cyan")
    table.add_column("Role")
    table.add_column("Node ID", style="dim")
    for agent in list_agents():
        table.add_row(str(agent["index"]), agent["name"], agent["role"], agent["id"])
    console.print(table)


@app.command()
def resumes() -> None:
    """List all resumes in the library."""
    profiles = load_all_resumes()
    table = Table(title="Resume Library", header_style="bold")
    table.add_column("ID", style="cyan")
    table.add_column("Name")
    table.add_column("Experience")
    table.add_column("Skills")
    table.add_column("Target Roles")
    for p in profiles:
        table.add_row(
            p.candidate_id, p.name, f"{p.experience_years:.0f} yrs",
            str(len(p.skills)), ", ".join(p.target_roles[:2]),
        )
    console.print(table)


@app.command()
def ui() -> None:
    """Launch Streamlit dashboard."""
    import subprocess
    ui_path = config.BASE_DIR / "ui" / "app.py"
    console.print(f"[cyan]streamlit run {ui_path}[/cyan]")
    subprocess.run(["streamlit", "run", str(ui_path)], check=False)


@app.command()
def demo() -> None:
    """Quick demo with first sample resume."""
    run(query="ML Engineer Python AI", resume=None, output=config.OUTPUT_DIR)


@app.command()
def demo_batch() -> None:
    """Run full end-to-end batch on all 6 resumes."""
    console.print(Panel.fit("[bold cyan]Batch Job Search[/bold cyan]\n[dim]Multi-resume end-to-end[/dim]"))
    _warn_demo_mode()
    _execute_batch()


def main() -> None:
    app()


if __name__ == "__main__":
    main()

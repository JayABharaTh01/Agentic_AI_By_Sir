"""Batch pipeline runner — end-to-end multi-resume job search."""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Callable, Iterator

from graph.workflow import get_graph, run_pipeline, stream_pipeline
from graph.state import initial_state, to_job_search_state
from models.schemas import BatchRunResult, JobSearchState, UserProfile
from services.output_manager import save_batch_results, save_candidate_results


def _build_comparison_report(results: list[JobSearchState], search_query: str) -> str:
    lines = [
        "=" * 70,
        "MULTI-RESUME COMPARISON REPORT",
        "=" * 70,
        f"Search query: {search_query or 'Auto from profiles'}",
        f"Candidates processed: {len(results)}",
        "",
        "-" * 70,
        "CANDIDATE SUMMARY",
        "-" * 70,
    ]

    for state in results:
        p = state.user_profile
        top = state.applications[0] if state.applications else None
        if top:
            lines.append(
                f"  {p.name} ({p.candidate_id}): "
                f"{p.experience_years:.0f} yrs | {len(p.skills)} skills | "
                f"Top: {top.match_score:.0f}% - {top.job_title} @ {top.company}"
            )
        else:
            lines.append(f"  {p.name} ({p.candidate_id}): no matches")

    lines.extend(["", "-" * 70, "TOP MATCHES ACROSS ALL CANDIDATES", "-" * 70])

    all_matches: list[tuple[float, str, str, str, str]] = []
    for state in results:
        p = state.user_profile
        for app in state.applications[:3]:
            all_matches.append(
                (app.match_score, p.name, p.candidate_id, app.job_title, app.company)
            )

    all_matches.sort(key=lambda x: x[0], reverse=True)
    for score, name, _cid, title, company in all_matches[:15]:
        lines.append(f"  [{score:.0f}%] {name} -> {title} @ {company}")

    lines.extend(["", "-" * 70, "SHORTLISTED JOBS PER CANDIDATE", "-" * 70])
    for state in results:
        p = state.user_profile
        shortlisted = [a for a in state.applications if a.job_id in state.shortlisted_job_ids]
        if shortlisted:
            jobs = ", ".join(f"{a.job_title} ({a.match_score:.0f}%)" for a in shortlisted)
            lines.append(f"  {p.name}: {jobs}")
        else:
            top3 = state.applications[:3]
            jobs = ", ".join(f"{a.job_title} ({a.match_score:.0f}%)" for a in top3)
            lines.append(f"  {p.name}: best matches — {jobs}")

    lines.extend(["", "=" * 70, "END OF COMPARISON", "=" * 70])
    return "\n".join(lines)


def _collect_top_matches(results: list[JobSearchState]) -> list[dict]:
    matches: list[dict] = []
    for state in results:
        p = state.user_profile
        for app in state.applications[:5]:
            matches.append({
                "candidate_id": p.candidate_id,
                "candidate_name": p.name,
                "job_title": app.job_title,
                "company": app.company,
                "match_score": app.match_score,
                "status": app.status.value,
            })
    matches.sort(key=lambda x: x["match_score"], reverse=True)
    return matches[:20]


def run_batch(
    profiles: list[UserProfile],
    search_query: str = "",
    save_output: bool = True,
    on_candidate_done: Callable[[int, int, JobSearchState], None] | None = None,
) -> BatchRunResult:
    """Run the full LangGraph pipeline for each resume end-to-end."""
    run_id = datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:6]
    results: list[JobSearchState] = []
    total = len(profiles)

    for i, profile in enumerate(profiles, 1):
        query = search_query or " ".join(profile.target_roles + profile.skills[:5])
        state = run_pipeline(profile=profile, search_query=query)
        results.append(state)
        if on_candidate_done:
            on_candidate_done(i, total, state)
        if save_output:
            save_candidate_results(state, run_id=run_id)

    comparison = _build_comparison_report(results, search_query)
    batch = BatchRunResult(
        run_id=run_id,
        search_query=search_query,
        completed_at=datetime.now(),
        candidate_results=results,
        comparison_report=comparison,
        total_candidates=len(results),
        total_jobs_matched=sum(len(r.applications) for r in results),
        top_matches_overall=_collect_top_matches(results),
    )

    if save_output:
        save_batch_results(batch)

    return batch


def stream_batch(
    profiles: list[UserProfile],
    search_query: str = "",
) -> Iterator[tuple[str, int, int, JobSearchState | None, dict | None]]:
    """
    Stream batch progress for UI.

    event_type: candidate_start | node | candidate_done | batch_done
    """
    total = len(profiles)
    all_results: list[JobSearchState] = []
    graph = get_graph()

    for i, profile in enumerate(profiles, 1):
        query = search_query or " ".join(profile.target_roles + profile.skills[:5])
        yield ("candidate_start", i, total, None, {
            "candidate_id": profile.candidate_id,
            "name": profile.name or profile.candidate_id,
        })

        init = initial_state(profile=profile, search_query=query)
        final: dict | None = None
        seen_nodes: set[str] = set()

        for chunk in graph.stream(init, stream_mode="values"):
            final = chunk
            agent = chunk.get("current_agent", "")
            if agent and agent not in seen_nodes:
                seen_nodes.add(agent)
                yield ("node", i, total, None, {
                    "node": agent,
                    "candidate_id": profile.candidate_id,
                })

        state = to_job_search_state(final or graph.invoke(init))
        all_results.append(state)
        yield ("candidate_done", i, total, state, None)

    comparison = _build_comparison_report(all_results, search_query)
    batch = BatchRunResult(
        run_id=datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:6],
        search_query=search_query,
        completed_at=datetime.now(),
        candidate_results=all_results,
        comparison_report=comparison,
        total_candidates=len(all_results),
        total_jobs_matched=sum(len(r.applications) for r in all_results),
        top_matches_overall=_collect_top_matches(all_results),
    )
    save_batch_results(batch)
    yield ("batch_done", total, total, None, batch.model_dump(mode="json"))

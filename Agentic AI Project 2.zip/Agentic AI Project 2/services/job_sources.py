"""Job listing sources — mock data and search utilities."""

from __future__ import annotations

import hashlib
from typing import Iterable

from models.schemas import JobListing, UserProfile

MOCK_JOBS: list[dict] = [
    {
        "title": "Senior ML Engineer",
        "company": "TechNova AI",
        "location": "Remote, US",
        "description": (
            "Build and deploy machine learning models at scale. Work with LLMs, "
            "MLOps pipelines, and cross-functional teams."
        ),
        "requirements": [
            "Python",
            "PyTorch or TensorFlow",
            "5+ years ML experience",
            "MLOps",
            "Cloud (AWS/GCP)",
        ],
        "salary_range": "$150,000 - $190,000",
        "url": "https://example.com/jobs/1",
        "source": "mock",
        "posted_date": "2026-07-01",
    },
    {
        "title": "AI Engineer",
        "company": "DataPulse",
        "location": "San Francisco, CA",
        "description": (
            "Design agentic AI systems and integrate LLM APIs into production "
            "workflows. Strong Python and FastAPI required."
        ),
        "requirements": [
            "Python",
            "FastAPI",
            "OpenAI/Anthropic APIs",
            "Agent frameworks",
            "3+ years experience",
        ],
        "salary_range": "$130,000 - $170,000",
        "url": "https://example.com/jobs/2",
        "source": "mock",
        "posted_date": "2026-07-05",
    },
    {
        "title": "Software Engineer - AI Platform",
        "company": "CloudScale",
        "location": "Remote, Global",
        "description": (
            "Build internal AI platform tooling. Kubernetes, Docker, Python, "
            "and distributed systems experience valued."
        ),
        "requirements": [
            "Python",
            "Kubernetes",
            "Docker",
            "Distributed systems",
            "4+ years experience",
        ],
        "salary_range": "$140,000 - $180,000",
        "url": "https://example.com/jobs/3",
        "source": "mock",
        "posted_date": "2026-07-08",
    },
    {
        "title": "Data Scientist",
        "company": "Insight Analytics",
        "location": "New York, NY",
        "description": (
            "Analyze large datasets, build predictive models, and communicate "
            "findings to stakeholders."
        ),
        "requirements": [
            "Python",
            "SQL",
            "Statistics",
            "Scikit-learn",
            "2+ years experience",
        ],
        "salary_range": "$110,000 - $140,000",
        "url": "https://example.com/jobs/4",
        "source": "mock",
        "posted_date": "2026-07-10",
    },
    {
        "title": "LLM Application Developer",
        "company": "PromptWorks",
        "location": "Austin, TX (Hybrid)",
        "description": (
            "Develop RAG pipelines, prompt engineering workflows, and "
            "multi-agent orchestration systems."
        ),
        "requirements": [
            "Python",
            "LangChain/LangGraph",
            "Vector databases",
            "RAG",
            "Prompt engineering",
        ],
        "salary_range": "$125,000 - $165,000",
        "url": "https://example.com/jobs/5",
        "source": "mock",
        "posted_date": "2026-07-12",
    },
    {
        "title": "Backend Engineer",
        "company": "FinTech Pro",
        "location": "Chicago, IL",
        "description": (
            "Build scalable APIs and microservices for financial products. "
            "Python or Go preferred."
        ),
        "requirements": [
            "Python",
            "REST APIs",
            "PostgreSQL",
            "Microservices",
            "3+ years experience",
        ],
        "salary_range": "$115,000 - $150,000",
        "url": "https://example.com/jobs/6",
        "source": "mock",
        "posted_date": "2026-07-03",
    },
    {
        "title": "Research Scientist - NLP",
        "company": "Language Labs",
        "location": "Seattle, WA",
        "description": (
            "Conduct NLP research, publish papers, and prototype transformer-based "
            "models for production."
        ),
        "requirements": [
            "PhD or equivalent",
            "PyTorch",
            "Transformers",
            "NLP",
            "Publications",
        ],
        "salary_range": "$160,000 - $220,000",
        "url": "https://example.com/jobs/7",
        "source": "mock",
        "posted_date": "2026-06-28",
    },
    {
        "title": "DevOps Engineer",
        "company": "InfraCore",
        "location": "Remote, US",
        "description": (
            "Manage CI/CD, infrastructure as code, and observability for AI "
            "workloads."
        ),
        "requirements": [
            "Kubernetes",
            "Terraform",
            "AWS",
            "CI/CD",
            "4+ years experience",
        ],
        "salary_range": "$130,000 - $165,000",
        "url": "https://example.com/jobs/8",
        "source": "mock",
        "posted_date": "2026-07-07",
    },
    {
        "title": "Analytics Engineer",
        "company": "DataBridge",
        "location": "New York, NY",
        "description": "Build data pipelines and analytics models for business teams.",
        "requirements": ["Python", "SQL", "Spark", "Statistics", "A/B Testing", "3+ years experience"],
        "salary_range": "$115,000 - $145,000",
        "url": "https://example.com/jobs/9",
        "source": "mock",
        "posted_date": "2026-07-09",
    },
    {
        "title": "Junior Software Engineer",
        "company": "StartupHub",
        "location": "San Francisco, CA",
        "description": "Entry-level role building web apps with mentorship from senior engineers.",
        "requirements": ["Python", "JavaScript", "Git", "REST APIs", "1+ years experience"],
        "salary_range": "$85,000 - $110,000",
        "url": "https://example.com/jobs/10",
        "source": "mock",
        "posted_date": "2026-07-11",
    },
    {
        "title": "Platform Engineer",
        "company": "CloudNative Co",
        "location": "Remote, US",
        "description": "Build internal developer platform on Kubernetes and Terraform.",
        "requirements": ["Kubernetes", "Terraform", "Python", "CI/CD", "AWS", "5+ years experience"],
        "salary_range": "$140,000 - $175,000",
        "url": "https://example.com/jobs/11",
        "source": "mock",
        "posted_date": "2026-07-06",
    },
    {
        "title": "MLOps Engineer",
        "company": "ModelServe",
        "location": "Remote, US",
        "description": "Deploy and monitor ML models in production with Docker and AWS.",
        "requirements": ["Python", "Docker", "MLOps", "AWS", "Machine Learning", "3+ years experience"],
        "salary_range": "$135,000 - $170,000",
        "url": "https://example.com/jobs/12",
        "source": "mock",
        "posted_date": "2026-07-04",
    },
]


def _job_id(title: str, company: str) -> str:
    raw = f"{title}|{company}".lower()
    return hashlib.md5(raw.encode()).hexdigest()[:12]


def dict_to_listing(data: dict) -> JobListing:
    return JobListing(
        id=_job_id(data["title"], data["company"]),
        title=data["title"],
        company=data["company"],
        location=data["location"],
        description=data["description"],
        requirements=data.get("requirements", []),
        salary_range=data.get("salary_range", ""),
        url=data.get("url", ""),
        source=data.get("source", "mock"),
        posted_date=data.get("posted_date", ""),
    )


def search_jobs(profile: UserProfile, query: str = "", limit: int = 10) -> list[JobListing]:
    """Search mock job listings filtered by profile and query."""
    keywords = set()
    keywords.update(s.lower() for s in profile.skills)
    keywords.update(r.lower() for r in profile.target_roles)
    if query:
        keywords.update(q.strip().lower() for q in query.split())

    scored: list[tuple[float, JobListing]] = []
    for job_data in MOCK_JOBS:
        listing = dict_to_listing(job_data)
        text = (
            f"{listing.title} {listing.company} {listing.description} "
            f"{' '.join(listing.requirements)}"
        ).lower()
        score = sum(1 for kw in keywords if kw and kw in text)
        if not keywords:
            score = 1.0
        scored.append((score, listing))

    scored.sort(key=lambda x: x[0], reverse=True)
    results = [job for _, job in scored[:limit]]
    if not results:
        results = [dict_to_listing(j) for j in MOCK_JOBS[:limit]]
    return results


def get_job_by_id(job_id: str, listings: Iterable[JobListing]) -> JobListing | None:
    for job in listings:
        if job.id == job_id:
            return job
    return None

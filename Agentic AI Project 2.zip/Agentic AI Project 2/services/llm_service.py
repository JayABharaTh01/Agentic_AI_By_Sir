"""LLM service for agent reasoning."""

from __future__ import annotations

import json
import re
from typing import Any, TypeVar

from openai import OpenAI
from pydantic import BaseModel

import config

T = TypeVar("T", bound=BaseModel)


class LLMService:
    """Wrapper around OpenAI-compatible chat completions."""

    def __init__(
        self,
        api_key: str | None = None,
        model: str | None = None,
        base_url: str | None = None,
    ) -> None:
        self.model = model or config.OPENAI_MODEL
        self._client: OpenAI | None = None
        self._api_key = api_key or config.OPENAI_API_KEY
        self._base_url = base_url or config.OPENAI_BASE_URL

    @property
    def client(self) -> OpenAI:
        if self._client is None:
            kwargs: dict[str, Any] = {"api_key": self._api_key or "not-set"}
            if self._base_url:
                kwargs["base_url"] = self._base_url
            self._client = OpenAI(**kwargs)
        return self._client

    @property
    def is_configured(self) -> bool:
        return bool(self._api_key and self._api_key != "your_openai_api_key_here")

    def chat(
        self,
        system_prompt: str,
        user_prompt: str,
        temperature: float = 0.3,
    ) -> str:
        if not self.is_configured:
            return self._fallback_response(system_prompt, user_prompt)

        response = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            temperature=temperature,
        )
        return response.choices[0].message.content or ""

    def chat_json(
        self,
        system_prompt: str,
        user_prompt: str,
        response_model: type[T],
        temperature: float = 0.2,
    ) -> T:
        schema_hint = json.dumps(response_model.model_json_schema(), indent=2)
        enhanced_system = (
            f"{system_prompt}\n\n"
            "Respond with valid JSON only, matching this schema:\n"
            f"{schema_hint}"
        )
        raw = self.chat(enhanced_system, user_prompt, temperature=temperature)
        parsed = self._extract_json(raw)
        return response_model.model_validate(parsed)

    def _extract_json(self, text: str) -> dict[str, Any]:
        text = text.strip()
        fence_match = re.search(r"```(?:json)?\s*([\s\S]*?)```", text)
        if fence_match:
            text = fence_match.group(1).strip()
        return json.loads(text)

    def _fallback_response(self, system_prompt: str, user_prompt: str) -> str:
        """Rule-based fallback when no API key is configured."""
        combined = (system_prompt + user_prompt).lower()
        if "cover letter" in combined:
            return (
                "Dear Hiring Manager,\n\n"
                "I am excited to apply for this role. My experience in Python and "
                "machine learning aligns well with your requirements, and I have a "
                "strong track record building production AI systems.\n\n"
                "I would welcome the opportunity to discuss how my background can "
                "contribute to your team.\n\n"
                "Sincerely,\nApplicant"
            )
        if "profile" in combined or "resume" in combined:
            return json.dumps(
                {
                    "name": "Jane Developer",
                    "skills": ["Python", "Machine Learning", "FastAPI", "SQL"],
                    "experience_years": 5,
                    "summary": "Experienced software engineer with AI/ML focus.",
                    "target_roles": ["ML Engineer", "AI Engineer"],
                }
            )
        if "match" in combined and "skill" in combined:
            return json.dumps(
                {
                    "match_score": 78.5,
                    "matched_skills": ["Python", "Machine Learning"],
                    "missing_skills": ["Kubernetes"],
                    "gap_analysis": "Strong core match; consider upskilling on Kubernetes.",
                    "recommendation": "Good fit — apply with tailored resume.",
                }
            )
        if "salary" in combined:
            return json.dumps(
                {
                    "market_estimate": "$120,000 - $160,000",
                    "competitiveness": "Competitive for mid-level role",
                    "negotiation_tips": [
                        "Highlight ML project impact",
                        "Research company band on Levels.fyi",
                    ],
                    "verdict": "Salary aligns with market expectations.",
                }
            )
        if "cover letter" in combined:
            return (
                "Dear Hiring Manager,\n\n"
                "I am excited to apply for this role. My experience in Python and "
                "machine learning aligns well with your requirements.\n\n"
                "Sincerely,\nApplicant"
            )
        if "interview" in combined:
            return json.dumps(
                {
                    "likely_questions": [
                        "Tell me about an ML project you shipped.",
                        "How do you evaluate model performance?",
                    ],
                    "suggested_answers": [
                        {
                            "question": "Tell me about an ML project you shipped.",
                            "answer": "Describe STAR format with metrics.",
                        }
                    ],
                    "questions_to_ask": ["What does success look like in 90 days?"],
                    "preparation_tips": ["Review job description keywords."],
                }
            )
        if "company" in combined:
            return json.dumps(
                {
                    "industry": "Technology",
                    "size": "500-1000 employees",
                    "culture_summary": "Innovation-focused, remote-friendly.",
                    "pros": ["Strong engineering culture", "Good benefits"],
                    "cons": ["Fast-paced environment"],
                    "interview_process": "Phone screen → technical → onsite",
                    "glassdoor_rating": "4.2/5",
                }
            )
        if "optimize" in combined or "ats" in combined:
            return json.dumps(
                {
                    "optimized_summary": "ML Engineer with 5+ years building production AI systems.",
                    "keyword_additions": ["LLM", "MLOps", "PyTorch"],
                    "bullet_rewrites": [
                        {
                            "original": "Built ML models",
                            "rewritten": "Deployed ML models serving 1M+ daily predictions",
                        }
                    ],
                    "ats_score": 82.0,
                }
            )
        return json.dumps({"result": "Analysis complete (demo mode — set OPENAI_API_KEY for live LLM)."})


_llm_instance: LLMService | None = None


def get_llm() -> LLMService:
    global _llm_instance
    if _llm_instance is None:
        _llm_instance = LLMService()
    return _llm_instance

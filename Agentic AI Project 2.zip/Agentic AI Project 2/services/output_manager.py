"""Save pipeline outputs per candidate and batch runs."""

from __future__ import annotations

import json
import re
from pathlib import Path

import config
from models.schemas import BatchRunResult, JobSearchState


def _slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_")


def candidate_output_dir(state: JobSearchState, run_id: str = "") -> Path:
    cid = state.user_profile.candidate_id or _slug(state.user_profile.name) or "candidate"
    base = config.OUTPUT_DIR / (run_id or "latest") / cid
    base.mkdir(parents=True, exist_ok=True)
    return base


def save_candidate_results(state: JobSearchState, run_id: str = "latest") -> Path:
    """Save all artifacts for one candidate run."""
    out_dir = candidate_output_dir(state, run_id)
    profile = state.user_profile

    (out_dir / "final_report.txt").write_text(state.final_report, encoding="utf-8")
    (out_dir / "full_results.json").write_text(state.model_dump_json(indent=2), encoding="utf-8")
    (out_dir / "profile.json").write_text(profile.model_dump_json(indent=2), encoding="utf-8")

    if profile.raw_resume:
        (out_dir / "original_resume.txt").write_text(profile.raw_resume, encoding="utf-8")

    for cl in state.cover_letters:
        job = next((j for j in state.job_listings if j.id == cl.job_id), None)
        slug = _slug(job.title if job else cl.job_id)
        (out_dir / f"cover_letter_{slug}.txt").write_text(cl.content, encoding="utf-8")

    for ro in state.resume_optimizations:
        job = next((j for j in state.job_listings if j.id == ro.job_id), None)
        slug = _slug(job.title if job else ro.job_id)
        if ro.optimized_resume_text:
            (out_dir / f"optimized_resume_{slug}.txt").write_text(
                ro.optimized_resume_text, encoding="utf-8"
            )
        meta = {
            "job": job.title if job else ro.job_id,
            "ats_score": ro.ats_score,
            "keywords": ro.keyword_additions,
            "summary": ro.optimized_summary,
        }
        (out_dir / f"resume_meta_{slug}.json").write_text(
            json.dumps(meta, indent=2), encoding="utf-8"
        )

    for ip in state.interview_preps:
        job = next((j for j in state.job_listings if j.id == ip.job_id), None)
        slug = _slug(job.title if job else ip.job_id)
        (out_dir / f"interview_prep_{slug}.json").write_text(
            ip.model_dump_json(indent=2), encoding="utf-8"
        )

    return out_dir


def save_batch_results(batch: BatchRunResult) -> Path:
    """Save batch comparison report and index."""
    run_dir = config.OUTPUT_DIR / batch.run_id
    run_dir.mkdir(parents=True, exist_ok=True)

    (run_dir / "comparison_report.txt").write_text(batch.comparison_report, encoding="utf-8")
    (run_dir / "batch_results.json").write_text(batch.model_dump_json(indent=2), encoding="utf-8")

    index_lines = [
        f"Batch Run: {batch.run_id}",
        f"Candidates: {batch.total_candidates}",
        f"Query: {batch.search_query}",
        "",
    ]
    for state in batch.candidate_results:
        p = state.user_profile
        top = state.applications[0] if state.applications else None
        index_lines.append(
            f"  {p.candidate_id}/  —  {p.name}  —  "
            f"top: {top.match_score:.0f}% {top.job_title}" if top else f"  {p.candidate_id}/  —  {p.name}"
        )
    (run_dir / "INDEX.txt").write_text("\n".join(index_lines), encoding="utf-8")

    for state in batch.candidate_results:
        save_candidate_results(state, run_id=batch.run_id)

    (config.OUTPUT_DIR / "latest_run.txt").write_text(batch.run_id, encoding="utf-8")

    return run_dir

"""Load resumes from the data/resumes directory or uploaded files."""

from __future__ import annotations

from pathlib import Path

import config
from models.schemas import UserProfile
from services.resume_parser import parse_resume_text, slug_from_path


def list_resume_files(directory: Path | None = None) -> list[Path]:
    """Return all .txt resume files sorted by name."""
    root = directory or config.RESUMES_DIR
    if not root.exists():
        return []
    return sorted(root.glob("*.txt"))


def load_resume(path: Path) -> UserProfile:
    """Load and parse a single resume file."""
    raw = path.read_text(encoding="utf-8")
    cid = slug_from_path(path)
    return parse_resume_text(raw, resume_file=str(path.name), candidate_id=cid)


def load_all_resumes(directory: Path | None = None) -> list[UserProfile]:
    """Load every resume in the resumes directory."""
    profiles: list[UserProfile] = []
    for path in list_resume_files(directory):
        profiles.append(load_resume(path))
    return profiles


def load_resumes_by_ids(candidate_ids: list[str], directory: Path | None = None) -> list[UserProfile]:
    """Load specific resumes by candidate_id (filename stem)."""
    all_files = {slug_from_path(p): p for p in list_resume_files(directory)}
    profiles: list[UserProfile] = []
    for cid in candidate_ids:
        path = all_files.get(cid)
        if path:
            profiles.append(load_resume(path))
    return profiles


def profile_from_text(raw: str, candidate_id: str = "uploaded") -> UserProfile:
    """Create profile from pasted or uploaded text."""
    return parse_resume_text(raw, resume_file="uploaded.txt", candidate_id=candidate_id)

"""Robust resume text parser for structured profile extraction."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from models.schemas import UserProfile

SKILL_KEYWORDS = {
    "python", "java", "javascript", "typescript", "sql", "r", "go", "rust",
    "machine learning", "deep learning", "pytorch", "tensorflow", "scikit-learn",
    "fastapi", "flask", "django", "react", "node.js", "docker", "kubernetes",
    "aws", "gcp", "azure", "terraform", "ci/cd", "mlops", "langchain", "langgraph",
    "openai", "rag", "nlp", "transformers", "hugging face", "pandas", "spark",
    "postgresql", "mongodb", "redis", "git", "rest apis", "microservices",
    "statistics", "a/b testing", "tableau", "prompt engineering", "vector databases",
    "agent frameworks", "distributed systems", "publications", "research",
}

EXPERIENCE_PATTERNS = [
    r"(\d+)\+?\s*years?",
    r"(\d+)\s*[-–]\s*(\d+)\s*years?",
]


def slug_from_path(path: Path | str) -> str:
    return Path(path).stem


def parse_resume_text(raw: str, resume_file: str = "", candidate_id: str = "") -> UserProfile:
    """Extract structured fields from plain-text resume."""
    lines = [ln.strip() for ln in raw.splitlines() if ln.strip()]
    cid = candidate_id or slug_from_path(resume_file) if resume_file else "candidate"

    name = _extract_name(lines)
    email = _extract_email(raw)
    phone = _extract_phone(raw)
    location = _extract_location(raw)
    summary = _extract_section(raw, ["PROFESSIONAL SUMMARY", "SUMMARY"])
    skills = _extract_skills(raw)
    education = _extract_education(raw)
    work_history = _extract_work_history(raw)
    target_roles = _extract_list_section(raw, ["TARGET ROLES", "OBJECTIVE"])
    salary = _extract_salary(raw)
    experience_years = _extract_experience_years(raw, work_history)

    return UserProfile(
        candidate_id=cid,
        resume_file=resume_file,
        name=name,
        email=email,
        phone=phone,
        location=location,
        summary=summary,
        skills=skills,
        experience_years=experience_years,
        education=education,
        work_history=work_history,
        target_roles=target_roles,
        target_locations=_extract_locations(location),
        salary_expectation=salary,
        raw_resume=raw,
    )


def _extract_name(lines: list[str]) -> str:
    if not lines:
        return ""
    first = lines[0]
    if "@" in first or "|" in first or re.match(r"^[\d\(\)\-+ ]+$", first):
        return ""
    if len(first.split()) <= 5 and not first.isupper() or first.istitle():
        return first
    return first.split("|")[0].strip()


def _extract_email(text: str) -> str:
    m = re.search(r"[\w.+-]+@[\w.-]+\.\w+", text)
    return m.group(0) if m else ""


def _extract_phone(text: str) -> str:
    m = re.search(r"\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}", text)
    return m.group(0) if m else ""


def _extract_location(text: str) -> str:
    header = text.split("\n")[0] if text else ""
    if "|" in header:
        parts = [p.strip() for p in header.split("|")]
        for p in parts[1:]:
            if "@" not in p and not re.search(r"\d{3}.*\d{4}", p):
                return p
    m = re.search(r"(Remote[^|\n]*|[A-Z][a-z]+,\s*[A-Z]{2})", text[:300])
    return m.group(0).strip() if m else ""


def _extract_locations(location: str) -> list[str]:
    if not location:
        return ["Remote", "US"]
    return [location]


def _extract_section(text: str, headers: list[str]) -> str:
    upper = text.upper()
    for header in headers:
        idx = upper.find(header)
        if idx == -1:
            continue
        start = idx + len(header)
        rest = text[start:].lstrip(":\n ")
        end_markers = ["TECHNICAL SKILLS", "SKILLS", "EXPERIENCE", "PROFESSIONAL EXPERIENCE", "EDUCATION"]
        end = len(rest)
        for marker in end_markers:
            pos = rest.upper().find(marker)
            if pos > 0:
                end = min(end, pos)
        return rest[:end].strip()
    return ""


def _extract_skills(text: str) -> list[str]:
    skills: list[str] = []
    section = _extract_section(text, ["TECHNICAL SKILLS", "SKILLS"])
    if section:
        parts = re.split(r"[,•|\n]", section)
        for p in parts:
            s = re.sub(r"^[•\-\*\s]+", "", p.strip())
            if s and len(s) < 50:
                skills.append(s.title() if s.islower() else s)

    body_lower = text.lower()
    for kw in SKILL_KEYWORDS:
        if kw in body_lower and kw.title() not in skills:
            label = kw.title() if kw != "ci/cd" else "CI/CD"
            if label not in skills:
                skills.append(label)

    return list(dict.fromkeys(skills))[:20]


def _extract_education(text: str) -> list[str]:
    items: list[str] = []
    section = _extract_section(text, ["EDUCATION"])
    if section:
        for line in section.split("\n"):
            line = line.strip()
            if line and not line.startswith("-"):
                items.append(line)
    return items


def _extract_work_history(text: str) -> list[dict[str, Any]]:
    history: list[dict[str, Any]] = []
    section = _extract_section(text, ["PROFESSIONAL EXPERIENCE", "EXPERIENCE", "WORK EXPERIENCE"])
    if not section:
        return history

    blocks = re.split(r"\n(?=[A-Z][^\n|]+\|)", section)
    for block in blocks:
        block = block.strip()
        if not block:
            continue
        lines = block.split("\n")
        title_line = lines[0]
        bullets = [ln.lstrip("-• ").strip() for ln in lines[1:] if ln.strip().startswith(("-", "•"))]
        if "|" in title_line:
            parts = [p.strip() for p in title_line.split("|")]
            history.append({
                "title": parts[0] if parts else "",
                "company": parts[1] if len(parts) > 1 else "",
                "dates": parts[2] if len(parts) > 2 else "",
                "bullets": bullets,
            })
        else:
            history.append({"title": title_line, "company": "", "dates": "", "bullets": bullets})
    return history


def _extract_list_section(text: str, headers: list[str]) -> list[str]:
    section = _extract_section(text, headers)
    if not section:
        return []
    return [p.strip() for p in re.split(r"[,|\n]", section) if p.strip()]


def _extract_salary(text: str) -> str:
    m = re.search(
        r"SALARY EXPECTATION\s*\n?\s*(\$[\d,]+[\s\-–]+[\$]?[\d,]+)",
        text,
        re.IGNORECASE,
    )
    if m:
        return m.group(1).replace("–", "-")
    m = re.search(r"\$[\d,]+[\s\-–]+[\$]?[\d,]+", text)
    return m.group(0).replace("–", "-") if m else ""


def _extract_experience_years(text: str, work_history: list[dict]) -> float:
    for pattern in EXPERIENCE_PATTERNS:
        m = re.search(pattern, text, re.IGNORECASE)
        if m:
            return float(m.group(1))

    if work_history:
        years = 0
        for job in work_history:
            dates = job.get("dates", "")
            found = re.findall(r"(20\d{2})", dates)
            if len(found) >= 2:
                years += max(0, int(found[-1]) - int(found[0]))
            elif len(found) == 1:
                years += max(0, 2026 - int(found[0]))
        if years > 0:
            return float(min(years, 30))

    return 2.0

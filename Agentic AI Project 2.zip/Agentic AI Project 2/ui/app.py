"""Job Search UI — agentic multi-candidate job board."""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import streamlit as st

import config
from graph.workflow import list_agents, run_pipeline, stream_pipeline
from models.schemas import BatchRunResult, JobSearchState, UserProfile
from services.batch_runner import stream_batch
from services.output_manager import save_candidate_results
from services.resume_loader import load_all_resumes, profile_from_text

st.set_page_config(
    page_title="JobSearch AI",
    page_icon="💼",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------------------------------------------------------------------------
# Styles — job board look & feel
# ---------------------------------------------------------------------------
st.markdown("""
<style>
    .job-card {
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        padding: 1.2rem 1.4rem;
        margin-bottom: 1rem;
        background: #ffffff;
        box-shadow: 0 1px 3px rgba(0,0,0,0.06);
    }
    .job-card:hover { border-color: #3b82f6; }
    .job-title { font-size: 1.15rem; font-weight: 700; color: #1e293b; margin: 0; }
    .job-company { font-size: 0.95rem; color: #64748b; margin: 0.2rem 0 0.6rem 0; }
    .job-meta { font-size: 0.85rem; color: #94a3b8; }
    .match-high { color: #16a34a; font-weight: 700; }
    .match-mid { color: #ca8a04; font-weight: 700; }
    .match-low { color: #dc2626; font-weight: 700; }
    .badge-shortlisted {
        background: #dcfce7; color: #166534;
        padding: 0.15rem 0.6rem; border-radius: 999px;
        font-size: 0.75rem; font-weight: 600;
    }
    .badge-matched {
        background: #dbeafe; color: #1e40af;
        padding: 0.15rem 0.6rem; border-radius: 999px;
        font-size: 0.75rem; font-weight: 600;
    }
    .badge-discovered {
        background: #f1f5f9; color: #475569;
        padding: 0.15rem 0.6rem; border-radius: 999px;
        font-size: 0.75rem; font-weight: 600;
    }
    .hero {
        background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
        color: white; padding: 1.8rem 2rem; border-radius: 14px;
        margin-bottom: 1.5rem;
    }
    .hero h1 { color: white !important; margin: 0; font-size: 1.8rem; }
    .hero p { color: #bfdbfe; margin: 0.4rem 0 0 0; }
    .skill-tag {
        display: inline-block; background: #eff6ff; color: #1d4ed8;
        padding: 0.15rem 0.55rem; border-radius: 6px;
        font-size: 0.78rem; margin: 0.15rem 0.2rem 0.15rem 0;
    }
    .stat-box {
        text-align: center; padding: 1rem;
        background: #f8fafc; border-radius: 10px; border: 1px solid #e2e8f0;
    }
    .stat-num { font-size: 1.6rem; font-weight: 800; color: #1e40af; }
    .stat-label { font-size: 0.8rem; color: #64748b; }
    div[data-testid="stSidebar"] { background: #f8fafc; }
</style>
""", unsafe_allow_html=True)


def _load_latest_batch() -> BatchRunResult | None:
    if not config.OUTPUT_DIR.exists():
        return None
    runs = sorted(
        [d for d in config.OUTPUT_DIR.iterdir() if d.is_dir() and (d / "batch_results.json").exists()],
        reverse=True,
    )
    if not runs:
        return None
    try:
        return BatchRunResult.model_validate_json((runs[0] / "batch_results.json").read_text(encoding="utf-8"))
    except Exception:
        return None


def _init():
    defaults = {
        "batch_result": None,
        "single_state": None,
        "active_candidate": None,
        "running": False,
        "search_log": [],
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v
    if st.session_state.batch_result is None:
        latest = _load_latest_batch()
        if latest:
            st.session_state.batch_result = latest
    if st.session_state.active_candidate is None:
        resumes = load_all_resumes()
        if resumes:
            st.session_state.active_candidate = resumes[0].candidate_id


def _match_class(score: float) -> str:
    if score >= 70:
        return "match-high"
    if score >= 45:
        return "match-mid"
    return "match-low"


def _status_badge(status: str, shortlisted: bool) -> str:
    if shortlisted or status == "shortlisted":
        return '<span class="badge-shortlisted">Shortlisted</span>'
    if status == "matched":
        return '<span class="badge-matched">Good Match</span>'
    return '<span class="badge-discovered">Discovered</span>'


def _job_card(app, job, match, shortlisted: bool, key_prefix: str = ""):
    """Render a single job listing card."""
    salary = job.salary_range if job else ""
    location = job.location if job else ""
    score = app.match_score
    mc = _match_class(score)
    badge = _status_badge(app.status.value, shortlisted)

    st.markdown(f"""
    <div class="job-card">
        <div style="display:flex; justify-content:space-between; align-items:flex-start;">
            <div>
                <p class="job-title">{app.job_title}</p>
                <p class="job-company">{app.company}</p>
                <p class="job-meta">{location} &nbsp;|&nbsp; {salary}</p>
            </div>
            <div style="text-align:right;">
                <p class="{mc}" style="font-size:1.4rem; margin:0;">{score:.0f}%</p>
                <p style="font-size:0.75rem; color:#94a3b8; margin:0;">match</p>
            </div>
        </div>
        <div style="margin-top:0.6rem;">{badge}</div>
    </div>
    """, unsafe_allow_html=True)

    if match and match.missing_skills:
        st.caption(f"Skills to develop: {', '.join(match.missing_skills[:4])}")


def _get_states() -> list[JobSearchState]:
    batch = st.session_state.batch_result
    single = st.session_state.single_state
    if batch:
        return batch.candidate_results
    if single:
        return [single]
    return []


def _get_active_state() -> JobSearchState | None:
    states = _get_states()
    if not states:
        return None
    cid = st.session_state.active_candidate
    for s in states:
        if s.user_profile.candidate_id == cid:
            return s
    return states[0]


def _sidebar():
    st.sidebar.markdown("## 💼 JobSearch AI")
    st.sidebar.caption("Your AI-powered job hunt assistant")

    key = config.OPENAI_API_KEY
    if key and key != "your_openai_api_key_here":
        st.sidebar.success("AI assistant active")
    else:
        st.sidebar.info("Demo mode — add API key for live AI")

    st.sidebar.markdown("---")

    # Candidate selector
    resumes = load_all_resumes()
    if resumes:
        st.sidebar.markdown("### 👤 Active Candidate")
        options = {p.candidate_id: p.name for p in resumes}
        choice = st.sidebar.selectbox(
            "Switch candidate",
            list(options.keys()),
            format_func=lambda x: options[x],
            index=list(options.keys()).index(st.session_state.active_candidate)
            if st.session_state.active_candidate in options else 0,
            label_visibility="collapsed",
        )
        st.session_state.active_candidate = choice

        active = next((p for p in resumes if p.candidate_id == choice), None)
        if active:
            st.sidebar.markdown(f"**{active.target_roles[0] if active.target_roles else 'Job Seeker'}**")
            st.sidebar.markdown(f"📍 {active.location or 'Remote'}")
            st.sidebar.markdown(f"💰 {active.salary_expectation or 'Not set'}")

    st.sidebar.markdown("---")
    state = _get_active_state()
    if state:
        st.sidebar.markdown("### 📊 Your Search Stats")
        st.sidebar.metric("Jobs Found", len(state.job_listings))
        st.sidebar.metric("Shortlisted", len(state.shortlisted_job_ids))
        st.sidebar.metric("Cover Letters Ready", len(state.cover_letters))
        if state.applications:
            st.sidebar.metric("Best Match", f"{state.applications[0].match_score:.0f}%")
    else:
        st.sidebar.markdown("*Run a job search to see stats*")

    st.sidebar.markdown("---")
    st.sidebar.markdown("### 📁 All Candidates")
    for p in resumes:
        icon = "✅" if _get_states() and any(
            s.user_profile.candidate_id == p.candidate_id for s in _get_states()
        ) else "👤"
        st.sidebar.markdown(f"{icon} {p.name}")


def _page_dashboard():
    st.markdown("""
    <div class="hero">
        <h1>Find Your Next Role</h1>
        <p>AI agents search jobs, match your skills, write cover letters, and prep you for interviews.</p>
    </div>
    """, unsafe_allow_html=True)

    states = _get_states()
    resumes = load_all_resumes()

    if not states:
        st.info("No job search results yet. Go to **Find Jobs** to start your search.")
        st.markdown("#### Available Candidates")
        cols = st.columns(min(len(resumes), 3))
        for i, p in enumerate(resumes[:6]):
            with cols[i % 3]:
                st.markdown(f"""
                <div class="job-card">
                    <p class="job-title">{p.name}</p>
                    <p class="job-company">{p.target_roles[0] if p.target_roles else 'Job Seeker'}</p>
                    <p class="job-meta">{p.experience_years:.0f} yrs exp &nbsp;|&nbsp; {len(p.skills)} skills</p>
                </div>
                """, unsafe_allow_html=True)
        return

    batch = st.session_state.batch_result
    c1, c2, c3, c4 = st.columns(4)
    total_jobs = sum(len(s.job_listings) for s in states)
    total_short = sum(len(s.shortlisted_job_ids) for s in states)
    total_letters = sum(len(s.cover_letters) for s in states)
    best = max(
        (a.match_score for s in states for a in s.applications),
        default=0,
    )
    for col, num, label in [(c1, len(states), "Candidates"), (c2, total_jobs, "Jobs Found"),
                             (c3, total_short, "Shortlisted"), (c4, f"{best:.0f}%", "Best Match")]:
        with col:
            st.markdown(f"""
            <div class="stat-box">
                <div class="stat-num">{num}</div>
                <div class="stat-label">{label}</div>
            </div>
            """, unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("### 🏆 Top Job Matches")

    all_apps: list[tuple[float, str, JobSearchState, object]] = []
    for s in states:
        for app in s.applications[:3]:
            all_apps.append((app.match_score, app.job_title, s, app))
    all_apps.sort(key=lambda x: x[0], reverse=True)

    cols = st.columns(2)
    for i, (score, title, state, app) in enumerate(all_apps[:6]):
        job = next((j for j in state.job_listings if j.id == app.job_id), None)
        match = next((m for m in state.skill_matches if m.job_id == app.job_id), None)
        shortlisted = app.job_id in state.shortlisted_job_ids
        with cols[i % 2]:
            st.markdown(f"**{state.user_profile.name}**")
            _job_card(app, job, match, shortlisted)


def _page_find_jobs():
    st.markdown("### 🔍 Find Jobs")
    st.caption("Search open roles matched to your skills and experience")

    resumes = load_all_resumes()
    if not resumes:
        st.error("No resumes found. Add .txt files to data/resumes/")
        return

    c1, c2 = st.columns([2, 1])
    with c1:
        query = st.text_input(
            "Job title or keywords",
            placeholder="e.g. ML Engineer, Python, Remote AI roles",
            value="",
        )
    with c2:
        scope = st.radio("Search for", ["All candidates", "Active candidate only"])

    active = st.session_state.active_candidate
    st.markdown("**Candidates to search:**")
    chip_cols = st.columns(min(len(resumes), 3))
    for i, p in enumerate(resumes):
        with chip_cols[i % 3]:
            selected = scope == "All candidates" or p.candidate_id == active
            st.markdown(f"{'✅' if selected else '⬜'} **{p.name}** — {p.target_roles[0] if p.target_roles else 'Open'}")

    if st.button("🚀 Search Jobs", type="primary", use_container_width=True, disabled=st.session_state.running):
        st.session_state.running = True
        st.session_state.search_log = []

        profiles = resumes if scope == "All candidates" else [
            next(p for p in resumes if p.candidate_id == active)
        ]

        progress = st.progress(0, text="Searching jobs...")
        log = st.empty()

        if len(profiles) > 1:
            step = 0
            for event_type, cur, total, state, meta in stream_batch(profiles, search_query=query):
                if event_type == "candidate_start":
                    progress.progress(cur / total, text=f"Searching for {meta['name']}...")
                elif event_type == "node" and meta.get("node") == "job_searcher":
                    st.session_state.search_log.append(f"Found jobs for {meta['candidate_id']}")
                elif event_type == "candidate_done":
                    step = cur
                    progress.progress(cur / total)
                elif event_type == "batch_done":
                    st.session_state.batch_result = BatchRunResult.model_validate(meta)
            st.success(f"Search complete for {len(profiles)} candidates!")
        else:
            profile = profiles[0]
            q = query or " ".join(profile.target_roles + profile.skills[:5])
            from graph.workflow import stream_pipeline_to_state
            progress.progress(0.3, text=f"Matching jobs for {profile.name}...")
            state = stream_pipeline_to_state(profile=profile, search_query=q)
            st.session_state.single_state = state
            save_candidate_results(state, run_id="single")
            st.session_state.batch_result = None
            top = state.applications[0] if state.applications else None
            st.success(f"Found {len(state.job_listings)} jobs! Best match: {top.match_score:.0f}%" if top else "Search complete!")

        st.session_state.running = False
        st.rerun()


def _page_job_matches():
    st.markdown("### 💼 Job Matches")
    state = _get_active_state()
    if not state:
        st.info("Run a job search first to see matched jobs.")
        return

    p = state.user_profile
    st.markdown(f"Showing matches for **{p.name}** — {p.target_roles[0] if p.target_roles else 'All roles'}")

    filter_col1, filter_col2 = st.columns(2)
    with filter_col1:
        show = st.selectbox("Filter", ["All jobs", "Shortlisted only", "70%+ match"])
    with filter_col2:
        sort = st.selectbox("Sort by", ["Match score", "Company", "Salary"])

    apps = list(state.applications)
    if show == "Shortlisted only":
        apps = [a for a in apps if a.job_id in state.shortlisted_job_ids]
    elif show == "70%+ match":
        apps = [a for a in apps if a.match_score >= 70]

    if sort == "Company":
        apps.sort(key=lambda a: a.company)
    elif sort == "Salary":
        apps.sort(key=lambda a: a.match_score, reverse=True)
    else:
        apps.sort(key=lambda a: a.match_score, reverse=True)

    if not apps:
        st.warning("No jobs match your filter.")
        return

    for app in apps:
        job = next((j for j in state.job_listings if j.id == app.job_id), None)
        match = next((m for m in state.skill_matches if m.job_id == app.job_id), None)
        shortlisted = app.job_id in state.shortlisted_job_ids
        _job_card(app, job, match, shortlisted)

        with st.expander(f"Details — {app.job_title} at {app.company}"):
            if job:
                st.markdown(f"**Description:** {job.description}")
                st.markdown(f"**Requirements:** {', '.join(job.requirements)}")
                if job.url:
                    st.markdown(f"[View job posting]({job.url})")
            if match:
                st.markdown(f"**Recommendation:** {match.recommendation}")
                if match.matched_skills:
                    st.markdown("**Your matching skills:**")
                    for sk in match.matched_skills:
                        st.markdown(f'<span class="skill-tag">{sk}</span>', unsafe_allow_html=True)
            salary_a = next((s for s in state.salary_analyses if s.job_id == app.job_id), None)
            if salary_a:
                st.markdown(f"**Salary:** {salary_a.listed_range} — {salary_a.verdict}")


def _page_application_kit():
    st.markdown("### ✉️ Application Kit")
    st.caption("Cover letters and tailored resumes ready to send")

    state = _get_active_state()
    if not state:
        st.info("Run a job search to generate application materials.")
        return

    p = state.user_profile
    st.markdown(f"Materials for **{p.name}**")

    kit_tabs = st.tabs(["Cover Letters", "Tailored Resumes"])

    with kit_tabs[0]:
        if not state.cover_letters:
            st.warning("No cover letters yet. Shortlisted jobs get cover letters automatically.")
        for cl in state.cover_letters:
            job = next((j for j in state.job_listings if j.id == cl.job_id), None)
            title = job.title if job else "Job"
            company = job.company if job else ""
            st.markdown(f"""
            <div class="job-card">
                <p class="job-title">Cover Letter — {title}</p>
                <p class="job-company">{company}</p>
            </div>
            """, unsafe_allow_html=True)
            st.text(cl.content)
            st.download_button(
                "📥 Download cover letter",
                cl.content,
                file_name=f"cover_letter_{title.replace(' ', '_').lower()}.txt",
                key=f"dl_cl_{cl.job_id}",
            )
            st.markdown("---")

    with kit_tabs[1]:
        if not state.resume_optimizations:
            st.warning("No tailored resumes yet.")
        for ro in state.resume_optimizations:
            job = next((j for j in state.job_listings if j.id == ro.job_id), None)
            title = job.title if job else "Job"
            st.markdown(f"""
            <div class="job-card">
                <p class="job-title">Resume for {title}</p>
                <p class="job-company">ATS Score: {ro.ats_score:.0f}%</p>
            </div>
            """, unsafe_allow_html=True)
            if ro.keyword_additions:
                st.markdown("**Keywords added:** " + ", ".join(ro.keyword_additions))
            st.text(ro.optimized_resume_text or ro.optimized_summary)
            if ro.optimized_resume_text:
                st.download_button(
                    "📥 Download tailored resume",
                    ro.optimized_resume_text,
                    file_name=f"resume_{title.replace(' ', '_').lower()}.txt",
                    key=f"dl_ro_{ro.job_id}",
                )
            st.markdown("---")


def _page_interview_prep():
    st.markdown("### 🎤 Interview Preparation")
    state = _get_active_state()
    if not state:
        st.info("Run a job search to get interview prep for your top matches.")
        return

    p = state.user_profile
    st.markdown(f"Interview prep for **{p.name}**")

    if not state.interview_preps:
        st.warning("No interview prep available yet.")
        return

    for ip in state.interview_preps:
        job = next((j for j in state.job_listings if j.id == ip.job_id), None)
        title = job.title if job else ip.job_id
        company = job.company if job else ""
        company_info = next((c for c in state.company_profiles if c.company == company), None)

        st.markdown(f"""
        <div class="job-card">
            <p class="job-title">{title}</p>
            <p class="job-company">{company}</p>
        </div>
        """, unsafe_allow_html=True)

        if company_info:
            st.markdown(f"**About {company}:** {company_info.culture_summary}")
            if company_info.interview_process:
                st.markdown(f"**Interview process:** {company_info.interview_process}")

        st.markdown("**Questions you'll likely be asked:**")
        for q in ip.likely_questions:
            st.markdown(f"- {q}")

        if ip.suggested_answers:
            with st.expander("Suggested answers"):
                for sa in ip.suggested_answers:
                    st.markdown(f"**Q:** {sa.get('question', '')}")
                    st.markdown(f"**A:** {sa.get('answer', '')}")

        st.markdown("**Questions to ask the interviewer:**")
        for q in ip.questions_to_ask:
            st.markdown(f"- {q}")

        if ip.preparation_tips:
            st.markdown("**Tips:**")
            for tip in ip.preparation_tips:
                st.markdown(f"- {tip}")
        st.markdown("---")


def _page_my_profile():
    st.markdown("### 👤 My Profile")
    resumes = load_all_resumes()

    profile_tabs = st.tabs(["My Resume", "Upload New", "All Candidates"])

    with profile_tabs[0]:
        active = st.session_state.active_candidate
        p = next((r for r in resumes if r.candidate_id == active), resumes[0] if resumes else None)
        if not p:
            st.info("No profile loaded.")
            return

        c1, c2 = st.columns([1, 2])
        with c1:
            st.markdown(f"## {p.name}")
            st.markdown(f"📧 {p.email}")
            st.markdown(f"📍 {p.location}")
            st.markdown(f"⏱ {p.experience_years:.0f} years experience")
            st.markdown(f"💰 {p.salary_expectation}")
            st.markdown("**Target roles:**")
            for role in p.target_roles:
                st.markdown(f"- {role}")
            st.markdown("**Skills:**")
            for sk in p.skills:
                st.markdown(f'<span class="skill-tag">{sk}</span>', unsafe_allow_html=True)
        with c2:
            st.text_area("Resume", p.raw_resume, height=400, disabled=True)

    with profile_tabs[1]:
        st.markdown("Upload or paste your resume to search for jobs")
        uploaded = st.file_uploader("Upload resume (.txt)", type=["txt"])
        pasted = st.text_area("Or paste resume text", height=200)
        query = st.text_input("What job are you looking for?", placeholder="Software Engineer, Remote")

        if st.button("Search jobs with this resume", type="primary"):
            raw = uploaded.read().decode("utf-8") if uploaded else pasted
            if not raw.strip():
                st.error("Please provide a resume.")
            else:
                profile = profile_from_text(raw, candidate_id="uploaded")
                with st.spinner("Searching jobs..."):
                    state = run_pipeline(profile=profile, search_query=query)
                    st.session_state.single_state = state
                    st.session_state.batch_result = None
                    st.session_state.active_candidate = "uploaded"
                    save_candidate_results(state, run_id="uploaded")
                st.success("Job search complete!")
                st.rerun()

    with profile_tabs[2]:
        for p in resumes:
            with st.expander(f"{p.name} — {p.target_roles[0] if p.target_roles else 'Job Seeker'}"):
                st.markdown(f"**Experience:** {p.experience_years:.0f} years | **Skills:** {len(p.skills)}")
                st.markdown(f"**Target:** {', '.join(p.target_roles)}")
                st.markdown(f"**Salary expectation:** {p.salary_expectation}")


def main():
    _init()
    _sidebar()

    page = st.navigation([
        st.Page(_page_dashboard, title="Dashboard", icon="🏠", default=True),
        st.Page(_page_find_jobs, title="Find Jobs", icon="🔍"),
        st.Page(_page_job_matches, title="Job Matches", icon="💼"),
        st.Page(_page_application_kit, title="Application Kit", icon="✉️"),
        st.Page(_page_interview_prep, title="Interview Prep", icon="🎤"),
        st.Page(_page_my_profile, title="My Profile", icon="👤"),
    ])

    page.run()


if __name__ == "__main__":
    main()

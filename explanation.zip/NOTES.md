# Agentic AI Data Analyst — Project Notes

## Overview

This project is a **multi-agent data analysis system** built with **LangGraph** and **Streamlit**. Upload a CSV file and three specialized agents collaborate to analyze your data, generate visualizations, and produce a markdown report.

---

## Architecture

```
┌─────────────┐
│  Streamlit  │  ← Frontend (CSV upload, charts, reports)
│   Frontend  │
└──────┬──────┘
       │
┌──────▼──────┐
│  Supervisor │  ← Routes workflow between agents
│    Agent    │
└──────┬──────┘
       │
   ┌───┼───┐
   ▼   ▼   ▼
┌────┐┌────┐┌────┐
│Data││Viz ││Rpt │  ← Specialist agents
│Anal││Agt ││Agt │
└────┘└────┘└────┘
```

### Agent Roles

| Agent | Responsibility |
|-------|---------------|
| **Supervisor** | Orchestrates the pipeline, routes to the next agent based on state |
| **Data Analyst** | Profiles the dataset, detects domain (retail/banking), generates insights |
| **Visualization** | Creates chart specifications (bar, line, histogram, scatter, pie) |
| **Report** | Compiles a final markdown report with findings and recommendations |

---

## Tech Stack

- **LangGraph** — Multi-agent workflow orchestration
- **LangChain + OpenAI** — LLM-powered analysis (optional)
- **Streamlit** — Web frontend
- **Pandas / NumPy** — Data processing
- **Plotly** — Interactive charts

---

## Quick Start

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Generate sample data (optional)

```bash
python generate_dummy_data.py
```

### 3. Configure API key (optional)

Copy `.env.example` to `.env` and add your OpenAI key for LLM-powered analysis. The system works **offline** with rule-based analysis if no key is provided.

### 4. Run the app

```bash
streamlit run app.py
```

---

## Sample Datasets

### Retail (5 files)

| File | Rows | Description |
|------|------|-------------|
| `retail_sales.csv` | 500 | Daily sales transactions with region, category, discounts |
| `retail_customers.csv` | 200 | Customer profiles with segments and lifetime value |
| `retail_inventory.csv` | 150 | Warehouse inventory with stock levels and reorder points |
| `retail_products.csv` | 100 | Product catalog with pricing and ratings |
| `retail_returns.csv` | 100 | Return records with reasons and refund amounts |

### Banking (5 files)

| File | Rows | Description |
|------|------|-------------|
| `banking_transactions.csv` | 600 | Account transactions across channels and branches |
| `banking_accounts.csv` | 150 | Account details with balances and status |
| `banking_loans.csv` | 100 | Loan portfolio with EMI and default tracking |
| `banking_customers.csv` | 200 | Customer segments with credit scores |
| `banking_fraud_alerts.csv` | 80 | Fraud detection alerts with severity levels |

---

## How the Pipeline Works

1. **Upload** a CSV or select a sample dataset
2. **Supervisor** checks state and routes to Data Analyst
3. **Data Analyst** profiles columns, detects domain, writes insights
4. **Supervisor** routes to Visualization Agent
5. **Visualization Agent** builds up to 5 chart specs based on column types
6. **Supervisor** routes to Report Agent
7. **Report Agent** compiles everything into a downloadable markdown report

### LLM vs Rule-Based Mode

| Feature | With API Key | Without API Key |
|---------|-------------|-----------------|
| Analysis | GPT-4o-mini insights | Statistical rule-based summary |
| Chart notes | LLM explanations | Auto-generated descriptions |
| Report | Professional narrative | Template-based report |

---

## Project Structure

```
ds agent/
├── app.py                  # Streamlit frontend
├── agents/
│   ├── state.py            # Shared agent state (TypedDict)
│   ├── tools.py            # Data analysis utilities
│   ├── nodes.py            # Agent node functions
│   └── graph.py            # LangGraph workflow definition
├── data/                   # 10 dummy CSV files
├── generate_dummy_data.py  # CSV generator script
├── requirements.txt
├── .env.example
└── NOTES.md                # This file
```

---

## Customization Ideas

- Add a **SQL Agent** that writes queries against uploaded data
- Add **anomaly detection** agent for fraud/retail outliers
- Connect to a **vector store** for RAG over historical reports
- Add **export to PDF** for reports
- Support **Excel** and **Parquet** uploads
- Add a **human-in-the-loop** approval step in the LangGraph workflow

---

## Troubleshooting

| Issue | Fix |
|-------|-----|
| `ModuleNotFoundError` | Run `pip install -r requirements.txt` |
| No charts generated | Ensure CSV has at least one numeric column |
| LLM errors | Check `OPENAI_API_KEY` in `.env` or sidebar |
| Empty analysis | Verify CSV is valid and not empty |

---

*Built with LangGraph + Streamlit — July 2026*

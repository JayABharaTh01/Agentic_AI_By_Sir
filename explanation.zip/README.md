# Agentic Data Analyst

Multi-agent CSV analysis system using **LangGraph** and **Streamlit**.

## Features

- Upload CSV files or use 10 built-in sample datasets (retail + banking)
- LangGraph multi-agent pipeline: Supervisor → Data Analyst → Visualization → Report
- Interactive Plotly charts (bar, line, histogram, scatter, pie)
- Markdown report generation with download
- Works with or without OpenAI API key

## Setup

```bash
pip install -r requirements.txt
python generate_dummy_data.py
streamlit run app.py
```

Optionally set `OPENAI_API_KEY` in `.env` for LLM-powered analysis.

See [NOTES.md](NOTES.md) for full documentation.

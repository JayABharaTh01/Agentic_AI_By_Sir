"""LangGraph workflow definition for the multi-agent system."""

from langgraph.graph import END, StateGraph

from agents.nodes import (
    data_analyst_node,
    report_node,
    route_after_supervisor,
    supervisor_node,
    visualization_node,
)
from agents.state import AgentState


def build_agent_graph():
    """Build and compile the multi-agent LangGraph workflow."""
    workflow = StateGraph(AgentState)

    workflow.add_node("supervisor", supervisor_node)
    workflow.add_node("data_analyst", data_analyst_node)
    workflow.add_node("visualization", visualization_node)
    workflow.add_node("report", report_node)

    workflow.set_entry_point("supervisor")

    workflow.add_conditional_edges(
        "supervisor",
        route_after_supervisor,
        {
            "data_analyst": "data_analyst",
            "visualization": "visualization",
            "report": "report",
            "end": END,
        },
    )

    workflow.add_edge("data_analyst", "supervisor")
    workflow.add_edge("visualization", "supervisor")
    workflow.add_edge("report", "supervisor")

    return workflow.compile()


# Singleton compiled graph
agent_graph = build_agent_graph()

"""LangGraph agent nodes for the multi-agent workflow."""

from __future__ import annotations

import json
import os
from typing import Any

import pandas as pd
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from langchain_openai import ChatOpenAI

from agents.state import AgentState
from agents.tools import (
    build_chart_specs,
    detect_domain,
    rule_based_analysis,
    rule_based_report,
    summarize_dataframe,
)


def _get_llm() -> ChatOpenAI | None:
    api_key = os.getenv("OPENAI_API_KEY", "")
    if not api_key or api_key == "your_openai_api_key_here":
        return None
    return ChatOpenAI(model="gpt-4o-mini", temperature=0.2)


def supervisor_node(state: AgentState) -> dict[str, Any]:
    """Route workflow to the appropriate next agent."""
    if state.get("error"):
        return {"next_agent": "end", "messages": [AIMessage(content="Workflow stopped due to error.")]}

    if not state.get("analysis_done"):
        return {"next_agent": "data_analyst", "messages": [AIMessage(content="Routing to Data Analyst...")]}

    if not state.get("viz_done"):
        return {"next_agent": "visualization", "messages": [AIMessage(content="Routing to Visualization Agent...")]}

    if not state.get("report_done"):
        return {"next_agent": "report", "messages": [AIMessage(content="Routing to Report Agent...")]}

    return {"next_agent": "end", "messages": [AIMessage(content="Analysis complete.")]}


def data_analyst_node(state: AgentState) -> dict[str, Any]:
    """Analyze uploaded CSV and produce insights."""
    try:
        import io

        df = pd.read_csv(io.StringIO(state["csv_data"]))
        domain = detect_domain(df)
        summary = summarize_dataframe(df)
        llm = _get_llm()

        if llm:
            prompt = f"""You are a senior data analyst. Analyze this dataset summary and provide actionable insights.

Domain: {domain}
Summary: {json.dumps(summary, default=str)}

Provide:
1. Dataset overview
2. Key patterns and anomalies
3. Business recommendations for {domain} domain
Keep response concise and use markdown."""

            response = llm.invoke(
                [
                    SystemMessage(content="You are an expert data analyst specializing in retail and banking analytics."),
                    HumanMessage(content=prompt),
                ]
            )
            analysis = response.content
        else:
            analysis = rule_based_analysis(df, summary, domain)

        return {
            "df_summary": summary,
            "domain": domain,
            "analysis_result": analysis,
            "analysis_done": True,
            "messages": [AIMessage(content=f"Data Analyst completed {domain} analysis.")],
        }
    except Exception as exc:
        return {"error": str(exc), "messages": [AIMessage(content=f"Data Analyst error: {exc}")]}


def visualization_node(state: AgentState) -> dict[str, Any]:
    """Generate chart specifications from analyzed data."""
    try:
        import io

        df = pd.read_csv(io.StringIO(state["csv_data"]))
        domain = state.get("domain", "general")
        chart_specs = build_chart_specs(df, domain)
        llm = _get_llm()

        if llm and chart_specs:
            prompt = f"""You are a visualization expert. Given these chart specs for {domain} data, 
briefly explain what each chart reveals (2-3 sentences total).

Charts: {json.dumps([s['title'] for s in chart_specs])}"""

            response = llm.invoke([HumanMessage(content=prompt)])
            viz_notes = response.content
        else:
            viz_notes = f"Generated {len(chart_specs)} charts based on column types and {domain} domain patterns."

        return {
            "chart_specs": chart_specs,
            "viz_done": True,
            "messages": [AIMessage(content=viz_notes)],
        }
    except Exception as exc:
        return {"error": str(exc), "messages": [AIMessage(content=f"Visualization error: {exc}")]}


def report_node(state: AgentState) -> dict[str, Any]:
    """Compile final markdown report from all agent outputs."""
    try:
        llm = _get_llm()
        analysis = state.get("analysis_result", "")
        domain = state.get("domain", "general")
        chart_count = len(state.get("chart_specs", []))

        if llm:
            prompt = f"""Compile a professional markdown report from this analysis.

Domain: {domain}
Analysis: {analysis}
Charts generated: {chart_count}

Include: Executive Summary, Key Findings, Recommendations, and Next Steps."""

            response = llm.invoke([HumanMessage(content=prompt)])
            report = response.content
        else:
            report = rule_based_report(analysis, domain, chart_count)

        return {
            "report": report,
            "report_done": True,
            "messages": [AIMessage(content="Report Agent compiled the final report.")],
        }
    except Exception as exc:
        return {"error": str(exc), "messages": [AIMessage(content=f"Report error: {exc}")]}


def route_after_supervisor(state: AgentState) -> str:
    """Conditional edge from supervisor to next agent or end."""
    next_agent = state.get("next_agent", "end")
    if next_agent == "end":
        return "end"
    return next_agent

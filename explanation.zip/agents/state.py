"""Shared state for the multi-agent LangGraph workflow."""

from typing import Annotated, Any, TypedDict

from langgraph.graph.message import add_messages


class AgentState(TypedDict):
    """State passed between agents in the graph."""

    messages: Annotated[list, add_messages]
    csv_data: str
    df_summary: dict[str, Any]
    analysis_result: str
    chart_specs: list[dict[str, Any]]
    report: str
    next_agent: str
    domain: str
    error: str
    analysis_done: bool
    viz_done: bool
    report_done: bool

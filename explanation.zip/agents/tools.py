"""Data analysis utilities used by agents."""

from __future__ import annotations

import json
from typing import Any

import numpy as np
import pandas as pd


def load_csv_from_bytes(content: bytes) -> pd.DataFrame:
    """Load CSV from uploaded file bytes."""
    import io

    return pd.read_csv(io.BytesIO(content))


def detect_domain(df: pd.DataFrame) -> str:
    """Infer whether data is retail or banking based on column names."""
    columns = " ".join(df.columns).lower()
    banking_keywords = {"account", "loan", "balance", "credit", "debit", "fraud", "branch", "ifsc"}
    retail_keywords = {"product", "sku", "store", "inventory", "category", "quantity", "discount"}

    banking_score = sum(1 for kw in banking_keywords if kw in columns)
    retail_score = sum(1 for kw in retail_keywords if kw in columns)

    if banking_score > retail_score:
        return "banking"
    if retail_score > banking_score:
        return "retail"
    return "general"


def summarize_dataframe(df: pd.DataFrame) -> dict[str, Any]:
    """Create a compact summary of the dataframe for agents."""
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    categorical_cols = df.select_dtypes(include=["object", "category"]).columns.tolist()
    datetime_cols = df.select_dtypes(include=["datetime64"]).columns.tolist()

    summary: dict[str, Any] = {
        "rows": len(df),
        "columns": df.columns.tolist(),
        "numeric_columns": numeric_cols,
        "categorical_columns": categorical_cols,
        "datetime_columns": datetime_cols,
        "missing_values": df.isnull().sum().to_dict(),
        "dtypes": {col: str(dtype) for col, dtype in df.dtypes.items()},
    }

    if numeric_cols:
        summary["numeric_stats"] = df[numeric_cols].describe().to_dict()

    if categorical_cols:
        summary["top_categories"] = {
            col: df[col].value_counts().head(5).to_dict()
            for col in categorical_cols[:5]
        }

    return summary


def build_chart_specs(df: pd.DataFrame, domain: str) -> list[dict[str, Any]]:
    """Generate chart specifications based on data shape and domain."""
    specs: list[dict[str, Any]] = []
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    categorical_cols = df.select_dtypes(include=["object", "category"]).columns.tolist()

    if not numeric_cols:
        return specs

    amount_col = _find_column(numeric_cols, ["amount", "total", "revenue", "sales", "balance", "price"])
    count_col = _find_column(categorical_cols, ["category", "type", "status", "region", "branch", "product"])
    date_col = _find_column(df.columns.tolist(), ["date", "timestamp", "created", "transaction_date"])

    if date_col and amount_col:
        df_copy = df.copy()
        df_copy[date_col] = pd.to_datetime(df_copy[date_col], errors="coerce")
        grouped = (
            df_copy.dropna(subset=[date_col])
            .groupby(df_copy[date_col].dt.date)[amount_col]
            .sum()
            .reset_index()
        )
        specs.append(
            {
                "type": "line",
                "title": f"{amount_col.title()} Trend Over Time",
                "x": grouped.columns[0],
                "y": amount_col,
                "data": grouped.to_dict(orient="records"),
            }
        )

    if count_col and amount_col:
        grouped = df.groupby(count_col)[amount_col].sum().reset_index().sort_values(amount_col, ascending=False).head(10)
        specs.append(
            {
                "type": "bar",
                "title": f"Top {count_col.title()} by {amount_col.title()}",
                "x": count_col,
                "y": amount_col,
                "data": grouped.to_dict(orient="records"),
            }
        )

    if amount_col:
        specs.append(
            {
                "type": "histogram",
                "title": f"Distribution of {amount_col.title()}",
                "x": amount_col,
                "data": df[[amount_col]].dropna().to_dict(orient="records"),
            }
        )

    if len(numeric_cols) >= 2:
        x_col, y_col = numeric_cols[0], numeric_cols[1]
        specs.append(
            {
                "type": "scatter",
                "title": f"{x_col.title()} vs {y_col.title()}",
                "x": x_col,
                "y": y_col,
                "data": df[[x_col, y_col]].dropna().head(200).to_dict(orient="records"),
            }
        )

    if domain == "banking" and count_col:
        status_counts = df[count_col].value_counts().reset_index()
        status_counts.columns = [count_col, "count"]
        specs.append(
            {
                "type": "pie",
                "title": f"{count_col.title()} Breakdown",
                "labels": count_col,
                "values": "count",
                "data": status_counts.to_dict(orient="records"),
            }
        )

    if domain == "retail" and count_col and amount_col:
        top_products = df.groupby(count_col)[amount_col].sum().nlargest(8).reset_index()
        specs.append(
            {
                "type": "bar",
                "title": "Top Performers",
                "x": count_col,
                "y": amount_col,
                "data": top_products.to_dict(orient="records"),
            }
        )

    return specs[:5]


def _find_column(columns: list[str], keywords: list[str]) -> str | None:
    for col in columns:
        if any(kw in col.lower() for kw in keywords):
            return col
    return columns[0] if columns else None


def rule_based_analysis(df: pd.DataFrame, summary: dict[str, Any], domain: str) -> str:
    """Generate analysis without LLM for offline/demo use."""
    lines = [
        f"## Dataset Overview",
        f"- **Rows:** {summary['rows']:,}",
        f"- **Columns:** {len(summary['columns'])}",
        f"- **Domain:** {domain.title()}",
        "",
        "## Column Profile",
    ]

    for col in summary["columns"]:
        missing = summary["missing_values"].get(col, 0)
        lines.append(f"- `{col}` ({summary['dtypes'][col]}) — {missing} missing values")

    if summary.get("numeric_stats"):
        lines.extend(["", "## Numeric Insights"])
        for col, stats in summary["numeric_stats"].items():
            lines.append(
                f"- **{col}**: mean={stats.get('mean', 0):.2f}, "
                f"min={stats.get('min', 0):.2f}, max={stats.get('max', 0):.2f}"
            )

    if summary.get("top_categories"):
        lines.extend(["", "## Category Highlights"])
        for col, counts in summary["top_categories"].items():
            top = list(counts.items())[:3]
            formatted = ", ".join(f"{k} ({v})" for k, v in top)
            lines.append(f"- **{col}**: {formatted}")

    if domain == "retail":
        lines.extend(
            [
                "",
                "## Retail Recommendations",
                "- Review top-selling categories for inventory planning.",
                "- Investigate low-quantity SKUs for potential stockouts.",
                "- Compare discount impact on revenue by store region.",
            ]
        )
    elif domain == "banking":
        lines.extend(
            [
                "",
                "## Banking Recommendations",
                "- Monitor high-value transactions for compliance review.",
                "- Track loan default rates by branch and customer segment.",
                "- Flag unusual account activity for fraud investigation.",
            ]
        )
    else:
        lines.extend(["", "## Recommendations", "- Explore correlations between numeric features.", "- Check data quality and missing value patterns."])

    return "\n".join(lines)


def rule_based_report(analysis: str, domain: str, chart_count: int) -> str:
    """Generate a markdown report from analysis."""
    return f"""# {domain.title()} Data Analysis Report

{analysis}

---

## Visualizations Generated
{chart_count} charts were automatically created based on your data structure.

## Next Steps
1. Review outliers in numeric distributions.
2. Validate categorical groupings for business relevance.
3. Export insights to stakeholders.
4. Re-run analysis after data cleaning if needed.
"""

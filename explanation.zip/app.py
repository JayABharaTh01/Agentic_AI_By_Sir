"""Streamlit frontend for the LangGraph multi-agent CSV analysis system."""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st
from dotenv import load_dotenv

from agents.graph import agent_graph
from agents.tools import detect_domain, summarize_dataframe

load_dotenv()

DATA_DIR = Path(__file__).parent / "data"
NOTES_PATH = Path(__file__).parent / "NOTES.md"

st.set_page_config(
    page_title="Agentic Data Analyst",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

CUSTOM_CSS = """
<style>
    .main-header { font-size: 2.2rem; font-weight: 700; color: #1e3a5f; }
    .agent-badge {
        display: inline-block; padding: 4px 12px; border-radius: 16px;
        font-size: 0.85rem; font-weight: 600; margin-right: 8px;
    }
    .agent-analyst { background: #dbeafe; color: #1e40af; }
    .agent-viz { background: #dcfce7; color: #166534; }
    .agent-report { background: #fef3c7; color: #92400e; }
    .metric-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 1rem; border-radius: 12px; color: white;
    }
</style>
"""
st.markdown(CUSTOM_CSS, unsafe_allow_html=True)


def render_chart(spec: dict) -> None:
    """Render a Plotly chart from a chart specification."""
    chart_type = spec["type"]
    data = pd.DataFrame(spec["data"])
    title = spec.get("title", "Chart")

    if chart_type == "bar":
        fig = px.bar(data, x=spec["x"], y=spec["y"], title=title, color=spec["y"], color_continuous_scale="Blues")
    elif chart_type == "line":
        fig = px.line(data, x=spec["x"], y=spec["y"], title=title, markers=True)
    elif chart_type == "histogram":
        fig = px.histogram(data, x=spec["x"], title=title, nbins=30, color_discrete_sequence=["#6366f1"])
    elif chart_type == "scatter":
        fig = px.scatter(data, x=spec["x"], y=spec["y"], title=title, opacity=0.6)
    elif chart_type == "pie":
        fig = px.pie(data, names=spec["labels"], values=spec["values"], title=title)
    else:
        st.warning(f"Unsupported chart type: {chart_type}")
        return

    fig.update_layout(template="plotly_white", height=400)
    st.plotly_chart(fig, use_container_width=True)


def run_agent_pipeline(csv_text: str) -> dict:
    """Execute the LangGraph multi-agent workflow."""
    initial_state = {
        "messages": [],
        "csv_data": csv_text,
        "df_summary": {},
        "analysis_result": "",
        "chart_specs": [],
        "report": "",
        "next_agent": "",
        "domain": "",
        "error": "",
        "analysis_done": False,
        "viz_done": False,
        "report_done": False,
    }
    return agent_graph.invoke(initial_state)


def page_upload_analyze() -> None:
    """Main page: upload CSV and run multi-agent analysis."""
    st.markdown('<p class="main-header">📊 Agentic Data Analyst</p>', unsafe_allow_html=True)
    st.markdown(
        "Upload a CSV and let the **multi-agent LangGraph system** analyze, visualize, and report on your data."
    )

    col1, col2, col3 = st.columns(3)
    with col1:
        st.markdown('<span class="agent-badge agent-analyst">🔍 Data Analyst</span>', unsafe_allow_html=True)
    with col2:
        st.markdown('<span class="agent-badge agent-viz">📈 Visualization</span>', unsafe_allow_html=True)
    with col3:
        st.markdown('<span class="agent-badge agent-report">📝 Report</span>', unsafe_allow_html=True)

    st.divider()

    uploaded = st.file_uploader("Upload your CSV file", type=["csv"])

    sample_files = sorted(DATA_DIR.glob("*.csv")) if DATA_DIR.exists() else []
    selected_sample = st.selectbox(
        "Or choose a sample dataset",
        ["— Select sample —"] + [f.name for f in sample_files],
    )

    csv_content: str | None = None
    df: pd.DataFrame | None = None

    if uploaded:
        csv_content = uploaded.read().decode("utf-8")
        df = pd.read_csv(uploaded)
        st.success(f"Loaded **{uploaded.name}** ({len(df):,} rows × {len(df.columns)} columns)")
    elif selected_sample != "— Select sample —":
        sample_path = DATA_DIR / selected_sample
        csv_content = sample_path.read_text(encoding="utf-8")
        df = pd.read_csv(sample_path)
        st.info(f"Using sample: **{selected_sample}** ({len(df):,} rows)")

    if df is not None and csv_content:
        with st.expander("Preview Data", expanded=False):
            st.dataframe(df.head(20), use_container_width=True)

        summary = summarize_dataframe(df)
        domain = detect_domain(df)

        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Rows", f"{summary['rows']:,}")
        m2.metric("Columns", len(summary["columns"]))
        m3.metric("Domain", domain.title())
        m4.metric("Missing Values", sum(summary["missing_values"].values()))

        if st.button("🚀 Run Multi-Agent Analysis", type="primary", use_container_width=True):
            with st.spinner("Agents working... Supervisor → Analyst → Visualization → Report"):
                result = run_agent_pipeline(csv_content)

            if result.get("error"):
                st.error(f"Pipeline error: {result['error']}")
            else:
                st.session_state["analysis_result"] = result
                st.success("Analysis complete!")

        if "analysis_result" in st.session_state:
            result = st.session_state["analysis_result"]

            st.divider()
            st.subheader("🤖 Agent Workflow Log")
            for msg in result.get("messages", []):
                st.chat_message("assistant").write(msg.content)

            tab1, tab2, tab3, tab4 = st.tabs(["📋 Analysis", "📊 Charts", "📝 Report", "🔧 Raw Summary"])

            with tab1:
                st.markdown(result.get("analysis_result", "No analysis available."))

            with tab2:
                specs = result.get("chart_specs", [])
                if specs:
                    chart_cols = st.columns(2)
                    for i, spec in enumerate(specs):
                        with chart_cols[i % 2]:
                            render_chart(spec)
                else:
                    st.info("No charts generated for this dataset.")

            with tab3:
                st.markdown(result.get("report", "No report generated."))
                st.download_button(
                    "Download Report (Markdown)",
                    data=result.get("report", ""),
                    file_name="analysis_report.md",
                    mime="text/markdown",
                )

            with tab4:
                st.json(result.get("df_summary", {}))


def page_notes() -> None:
    """Display project notes from NOTES.md."""
    st.markdown('<p class="main-header">📓 Project Notes</p>', unsafe_allow_html=True)

    if NOTES_PATH.exists():
        st.markdown(NOTES_PATH.read_text(encoding="utf-8"))
    else:
        st.warning("NOTES.md not found.")


def page_samples() -> None:
    """Browse and preview sample CSV datasets."""
    st.markdown('<p class="main-header">🗂️ Sample Datasets</p>', unsafe_allow_html=True)
    st.markdown("10 dummy CSV files for **retail** and **banking** testing.")

    if not DATA_DIR.exists():
        st.error("Data directory not found. Run `python generate_dummy_data.py` first.")
        return

    retail_files = sorted(DATA_DIR.glob("retail_*.csv"))
    banking_files = sorted(DATA_DIR.glob("banking_*.csv"))

    col_r, col_b = st.columns(2)

    with col_r:
        st.subheader("🛒 Retail")
        for f in retail_files:
            df = pd.read_csv(f)
            with st.expander(f"{f.name} ({len(df)} rows)"):
                st.dataframe(df.head(10), use_container_width=True)

    with col_b:
        st.subheader("🏦 Banking")
        for f in banking_files:
            df = pd.read_csv(f)
            with st.expander(f"{f.name} ({len(df)} rows)"):
                st.dataframe(df.head(10), use_container_width=True)


def main() -> None:
    with st.sidebar:
        st.title("Navigation")
        page = st.radio(
            "Go to",
            ["Upload & Analyze", "Sample Datasets", "Notes"],
            label_visibility="collapsed",
        )
        st.divider()
        st.markdown("### Agent Pipeline")
        st.markdown("""
        ```
        Supervisor
            ↓
        Data Analyst
            ↓
        Visualization
            ↓
        Report Agent
        ```
        """)
        st.divider()
        api_key = st.text_input("OpenAI API Key (optional)", type="password", help="Enables LLM-powered analysis. Works offline without it.")
        if api_key:
            import os
            os.environ["OPENAI_API_KEY"] = api_key

    if page == "Upload & Analyze":
        page_upload_analyze()
    elif page == "Sample Datasets":
        page_samples()
    else:
        page_notes()


if __name__ == "__main__":
    main()

"""Generate 10 dummy CSV files for retail and banking domains."""

from pathlib import Path

import numpy as np
import pandas as pd

np.random.seed(42)
DATA_DIR = Path(__file__).parent / "data"
DATA_DIR.mkdir(exist_ok=True)


def generate_retail_sales() -> None:
    dates = pd.date_range("2024-01-01", periods=500, freq="D")
    regions = ["North", "South", "East", "West", "Central"]
    categories = ["Electronics", "Clothing", "Groceries", "Home", "Sports"]
    df = pd.DataFrame(
        {
            "transaction_id": [f"TXN-{i:05d}" for i in range(1, 501)],
            "transaction_date": np.random.choice(dates, 500),
            "store_region": np.random.choice(regions, 500),
            "category": np.random.choice(categories, 500),
            "product_name": [f"Product-{np.random.randint(1, 50)}" for _ in range(500)],
            "quantity": np.random.randint(1, 20, 500),
            "unit_price": np.round(np.random.uniform(5, 500, 500), 2),
            "discount_pct": np.round(np.random.uniform(0, 30, 500), 1),
        }
    )
    df["total_amount"] = np.round(df["quantity"] * df["unit_price"] * (1 - df["discount_pct"] / 100), 2)
    df.to_csv(DATA_DIR / "retail_sales.csv", index=False)


def generate_retail_customers() -> None:
    segments = ["Premium", "Standard", "Budget", "New"]
    df = pd.DataFrame(
        {
            "customer_id": [f"CUST-{i:04d}" for i in range(1, 201)],
            "name": [f"Customer {i}" for i in range(1, 201)],
            "email": [f"customer{i}@email.com" for i in range(1, 201)],
            "segment": np.random.choice(segments, 200),
            "loyalty_points": np.random.randint(0, 10000, 200),
            "total_purchases": np.random.randint(1, 100, 200),
            "lifetime_value": np.round(np.random.uniform(100, 50000, 200), 2),
            "region": np.random.choice(["North", "South", "East", "West"], 200),
            "signup_date": pd.date_range("2020-01-01", periods=200, freq="5D"),
        }
    )
    df.to_csv(DATA_DIR / "retail_customers.csv", index=False)


def generate_retail_inventory() -> None:
    categories = ["Electronics", "Clothing", "Groceries", "Home", "Sports"]
    df = pd.DataFrame(
        {
            "sku": [f"SKU-{i:04d}" for i in range(1, 151)],
            "product_name": [f"Item-{i}" for i in range(1, 151)],
            "category": np.random.choice(categories, 150),
            "warehouse": np.random.choice(["WH-North", "WH-South", "WH-East"], 150),
            "quantity_in_stock": np.random.randint(0, 500, 150),
            "reorder_level": np.random.randint(10, 50, 150),
            "unit_cost": np.round(np.random.uniform(2, 200, 150), 2),
            "last_restocked": pd.date_range("2024-06-01", periods=150, freq="2D"),
        }
    )
    df.to_csv(DATA_DIR / "retail_inventory.csv", index=False)


def generate_retail_products() -> None:
    categories = ["Electronics", "Clothing", "Groceries", "Home", "Sports"]
    df = pd.DataFrame(
        {
            "product_id": [f"PROD-{i:04d}" for i in range(1, 101)],
            "product_name": [f"Product {i}" for i in range(1, 101)],
            "category": np.random.choice(categories, 100),
            "brand": np.random.choice(["BrandA", "BrandB", "BrandC", "BrandD"], 100),
            "price": np.round(np.random.uniform(10, 1000, 100), 2),
            "rating": np.round(np.random.uniform(1, 5, 100), 1),
            "reviews_count": np.random.randint(0, 500, 100),
            "in_stock": np.random.choice([True, False], 100),
        }
    )
    df.to_csv(DATA_DIR / "retail_products.csv", index=False)


def generate_retail_returns() -> None:
    reasons = ["Defective", "Wrong Item", "Changed Mind", "Late Delivery", "Damaged"]
    df = pd.DataFrame(
        {
            "return_id": [f"RET-{i:04d}" for i in range(1, 101)],
            "transaction_id": [f"TXN-{np.random.randint(1, 500):05d}" for _ in range(100)],
            "return_date": pd.date_range("2024-03-01", periods=100, freq="3D"),
            "reason": np.random.choice(reasons, 100),
            "refund_amount": np.round(np.random.uniform(10, 500, 100), 2),
            "category": np.random.choice(["Electronics", "Clothing", "Groceries", "Home"], 100),
            "status": np.random.choice(["Approved", "Pending", "Rejected"], 100),
        }
    )
    df.to_csv(DATA_DIR / "retail_returns.csv", index=False)


def generate_banking_transactions() -> None:
    types = ["Credit", "Debit", "Transfer", "Withdrawal", "Deposit"]
    df = pd.DataFrame(
        {
            "transaction_id": [f"BT-{i:06d}" for i in range(1, 601)],
            "account_id": [f"ACC-{np.random.randint(1, 150):04d}" for _ in range(600)],
            "transaction_date": pd.date_range("2024-01-01", periods=600, freq="12h"),
            "type": np.random.choice(types, 600),
            "amount": np.round(np.random.uniform(10, 50000, 600), 2),
            "balance_after": np.round(np.random.uniform(1000, 200000, 600), 2),
            "branch": np.random.choice(["Downtown", "Uptown", "Suburban", "Airport"], 600),
            "channel": np.random.choice(["ATM", "Online", "Branch", "Mobile"], 600),
        }
    )
    df.to_csv(DATA_DIR / "banking_transactions.csv", index=False)


def generate_banking_accounts() -> None:
    types = ["Savings", "Checking", "Fixed Deposit", "Business"]
    statuses = ["Active", "Dormant", "Closed", "Frozen"]
    df = pd.DataFrame(
        {
            "account_id": [f"ACC-{i:04d}" for i in range(1, 151)],
            "customer_id": [f"BC-{i:04d}" for i in range(1, 151)],
            "account_type": np.random.choice(types, 150),
            "balance": np.round(np.random.uniform(500, 500000, 150), 2),
            "status": np.random.choice(statuses, 150, p=[0.7, 0.15, 0.1, 0.05]),
            "branch": np.random.choice(["Downtown", "Uptown", "Suburban", "Airport"], 150),
            "opened_date": pd.date_range("2018-01-01", periods=150, freq="10D"),
            "ifsc_code": [f"BNK0{i:04d}" for i in np.random.randint(1000, 9999, 150)],
        }
    )
    df.to_csv(DATA_DIR / "banking_accounts.csv", index=False)


def generate_banking_loans() -> None:
    types = ["Home", "Personal", "Auto", "Education", "Business"]
    statuses = ["Active", "Paid Off", "Defaulted", "Pending"]
    df = pd.DataFrame(
        {
            "loan_id": [f"LN-{i:04d}" for i in range(1, 101)],
            "customer_id": [f"BC-{np.random.randint(1, 150):04d}" for _ in range(100)],
            "loan_type": np.random.choice(types, 100),
            "principal_amount": np.round(np.random.uniform(10000, 500000, 100), 2),
            "interest_rate": np.round(np.random.uniform(3, 15, 100), 2),
            "tenure_months": np.random.choice([12, 24, 36, 48, 60, 120, 240], 100),
            "emi_amount": np.round(np.random.uniform(500, 15000, 100), 2),
            "status": np.random.choice(statuses, 100, p=[0.6, 0.2, 0.1, 0.1]),
            "branch": np.random.choice(["Downtown", "Uptown", "Suburban"], 100),
        }
    )
    df.to_csv(DATA_DIR / "banking_loans.csv", index=False)


def generate_banking_customers() -> None:
    segments = ["Retail", "Premium", "Corporate", "SME"]
    df = pd.DataFrame(
        {
            "customer_id": [f"BC-{i:04d}" for i in range(1, 201)],
            "name": [f"Client {i}" for i in range(1, 201)],
            "segment": np.random.choice(segments, 200),
            "credit_score": np.random.randint(300, 850, 200),
            "annual_income": np.round(np.random.uniform(20000, 500000, 200), 2),
            "num_accounts": np.random.randint(1, 5, 200),
            "kyc_status": np.random.choice(["Verified", "Pending", "Expired"], 200, p=[0.8, 0.15, 0.05]),
            "branch": np.random.choice(["Downtown", "Uptown", "Suburban", "Airport"], 200),
        }
    )
    df.to_csv(DATA_DIR / "banking_customers.csv", index=False)


def generate_banking_fraud_alerts() -> None:
    severities = ["Low", "Medium", "High", "Critical"]
    statuses = ["Open", "Investigating", "Resolved", "False Positive"]
    df = pd.DataFrame(
        {
            "alert_id": [f"FRD-{i:04d}" for i in range(1, 81)],
            "account_id": [f"ACC-{np.random.randint(1, 150):04d}" for _ in range(80)],
            "alert_date": pd.date_range("2024-06-01", periods=80, freq="2D"),
            "fraud_type": np.random.choice(
                ["Unusual Transfer", "Identity Theft", "Card Skimming", "Account Takeover", "Money Laundering"],
                80,
            ),
            "amount": np.round(np.random.uniform(100, 100000, 80), 2),
            "severity": np.random.choice(severities, 80, p=[0.3, 0.35, 0.25, 0.1]),
            "status": np.random.choice(statuses, 80),
            "branch": np.random.choice(["Downtown", "Uptown", "Suburban", "Airport"], 80),
        }
    )
    df.to_csv(DATA_DIR / "banking_fraud_alerts.csv", index=False)


if __name__ == "__main__":
    generators = [
        ("retail_sales.csv", generate_retail_sales),
        ("retail_customers.csv", generate_retail_customers),
        ("retail_inventory.csv", generate_retail_inventory),
        ("retail_products.csv", generate_retail_products),
        ("retail_returns.csv", generate_retail_returns),
        ("banking_transactions.csv", generate_banking_transactions),
        ("banking_accounts.csv", generate_banking_accounts),
        ("banking_loans.csv", generate_banking_loans),
        ("banking_customers.csv", generate_banking_customers),
        ("banking_fraud_alerts.csv", generate_banking_fraud_alerts),
    ]

    print("Generating dummy CSV files...")
    for name, fn in generators:
        fn()
        print(f"  [OK] {name}")
    print(f"\nDone! Files saved to {DATA_DIR}")

"""Quick script to test the LangGraph pipeline on sample datasets."""

from pathlib import Path

from agents.graph import agent_graph

DATA_DIR = Path(__file__).parent / "data"
SAMPLES = ["retail_sales.csv", "banking_transactions.csv"]


def run_pipeline(csv_path: Path) -> dict:
    return agent_graph.invoke(
        {
            "messages": [],
            "csv_data": csv_path.read_text(encoding="utf-8"),
            "df_summary": {},
            "analysis_result": "",
            "chart_specs": [],
            "report": "",
            "next_agent": "",
            "domain": "",
            "error": "",
            "analysis_done": False,
            "viz_done": False,
            "report_done": False,
        }
    )


if __name__ == "__main__":
    print("Running multi-agent pipeline tests...\n")
    for name in SAMPLES:
        path = DATA_DIR / name
        result = run_pipeline(path)
        print(f"{name}:")
        print(f"  domain     = {result.get('domain')}")
        print(f"  charts     = {len(result.get('chart_specs', []))}")
        print(f"  report     = {'OK' if result.get('report') else 'MISSING'}")
        print(f"  error      = {result.get('error') or 'none'}")
        print()
    print("Pipeline build complete.")
